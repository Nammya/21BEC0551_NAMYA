const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;

app.use(express.json());
app.use(cors());

app.post('/bfhl', (req, res) => {
  try {
    const { data } = req.body;

    if (!data || !Array.isArray(data)) {
      throw new Error("Invalid input");
    }

    const numbers = data.filter(item => !isNaN(item));
    const alphabets = data.filter(item => /^[a-zA-Z]+$/.test(item));
    const highestLowercase = alphabets
      .filter(item => /^[a-z]+$/.test(item))
      .sort()
      .pop();

    const response = {
      is_success: true,
      user_id: "namya_prakash_14062023", 
      email: "namya@xyz.com",    
      roll_number: "21BEC0551",
      numbers,
      alphabets,
      highest_lowercase_alphabet: highestLowercase ? [highestLowercase] : []
    };

    res.status(200).json(response);
  } catch (error) {
    res.status(400).json({ is_success: false, message: error.message });
  }
});

app.get('/bfhl', (req, res) => {
  res.status(200).json({ operation_code: 1 });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});