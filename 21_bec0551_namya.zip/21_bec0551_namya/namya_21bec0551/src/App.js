import React, { useState } from 'react';

function App() {
  const [inputData, setInputData] = useState('');
  const [responseData, setResponseData] = useState(null);
  const [selectedFilters, setSelectedFilters] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/bfhl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: JSON.parse(inputData) })
      });

      const data = await response.json();
      setResponseData(data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleFilterChange = (e) => {
    const { value, checked } = e.target;
    setSelectedFilters((prev) =>
      checked ? [...prev, value] : prev.filter((v) => v !== value)
    );
  };

  const filteredResponse = responseData && {
    ...responseData,
    numbers: selectedFilters.includes('Numbers') ? responseData.numbers : [],
    alphabets: selectedFilters.includes('Alphabets') ? responseData.alphabets : [],
    highest_lowercase_alphabet: selectedFilters.includes('Highest lowercase alphabet') ? responseData.highest_lowercase_alphabet : []
  };

  return (
    <div>
      <h1>21BEC0551</h1>
      <form onSubmit={handleSubmit}>
        <textarea
          value={inputData}
          onChange={(e) => setInputData(e.target.value)}
          placeholder='Enter JSON data'
        />
        <button type='submit'>Submit</button>
      </form>

      {responseData && (
        <>
          <div>
            <label>
              <input
                type='checkbox'
                value='Numbers'
                onChange={handleFilterChange}
              /> Numbers
            </label>
            <label>
              <input
                type='checkbox'
                value='Alphabets'
                onChange={handleFilterChange}
              /> Alphabets
            </label>
            <label>
              <input
                type='checkbox'
                value='Highest lowercase alphabet'
                onChange={handleFilterChange}
              /> Highest lowercase alphabet
            </label>
          </div>

          <pre>{JSON.stringify(filteredResponse, null, 2)}</pre>
        </>
      )}
    </div>
  );
}

export default App;
